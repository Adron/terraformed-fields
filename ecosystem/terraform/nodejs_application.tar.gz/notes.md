

Some additional references I read up on to use for deployment and production setup of a Node.js Application included the following.

* [Heroku's "Best Practices for Node.js Development"](https://devcenter.heroku.com/articles/node-best-practices)
* [Strongloop's "Best Practices for Deploying Node.js Code in Production"](https://strongloop.com/strongblog/node-js-deploy-production-best-practice/) (Not entirely usable for us directly, but the ideas are valid)
* [Strongloop's "Best Practices for Express in Production - Part One: Security"](https://strongloop.com/strongblog/best-practices-for-express-in-production-part-one-security/)
* [RisingStack Engineering's "Node.js Production Checklist"](https://blog.risingstack.com/node-js-production-checklist/)
* [RisingStack Engineering's "Shipping Node.js with Docker & Codeship"](https://blog.risingstack.com/shipping-node-js-applications-with-docker-and-codeship/)
* [RisingStack Engineering's "Node.js Best Practices"](https://blog.risingstack.com/node-js-best-practices/)
* [RisingStack Engineering's "Node.js Best Practices - Part 2"](https://blog.risingstack.com/node-js-best-practices-part-2/)
* [RisingStack Engineering's "Operating Node.js in Production"](https://blog.risingstack.com/operating-node-in-production/)
